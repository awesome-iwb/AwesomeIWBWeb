import { sql } from "../db/client";

export type FeedbackKind = "comment" | "bug";
export type FeedbackStatus = "open" | "doing" | "done";

export type FeedbackEntry = {
  id: string;
  project_name: string;
  kind: FeedbackKind;
  title: string;
  body: string;
  labels: string[];
  status: FeedbackStatus;
  actor_username: string;
  actor_role: string;
  actor_avatar_url: string;
  created_at: string;
  updated_at: string;
};

export async function listFeedback(input: {
  project_name?: string;
  project_names?: string[];
  kind?: FeedbackKind;
  status?: "open" | "closed";
  limit?: number;
  page?: number;
  pageSize?: number;
  ids?: string[];
}) {
  const where: string[] = [];
  const params: any[] = [];

  if (input.project_name) {
    params.push(input.project_name);
    where.push(`project_name = $${params.length}`);
  }
  if (input.project_names && input.project_names.length > 0) {
    const list = input.project_names.map(n => `'${n.replace(/'/g, "''")}'`).join(",");
    where.push(`project_name in (${list})`);
  }
  if (input.kind) {
    params.push(input.kind);
    where.push(`kind = $${params.length}`);
  }
  if (input.status === "open") where.push(`status <> 'done'`);
  if (input.status === "closed") where.push(`status = 'done'`);
  if (input.ids && input.ids.length > 0) {
    const idList = input.ids.map(id => `'${id.replace(/'/g, "''")}'`).join(",");
    where.push(`id in (${idList})`);
  }

  const clause = where.length ? `where ${where.join(" and ")}` : "";

  if (input.page || input.pageSize) {
    const page = Math.max(1, input.page ?? 1);
    const pageSize = Math.min(100, Math.max(1, input.pageSize ?? 20));
    const offset = (page - 1) * pageSize;
    const rows = await sql().unsafe(
      `select fe.id, fe.project_name, fe.kind, fe.title, fe.body, fe.labels, fe.status,
              fe.actor_username, fe.actor_role, coalesce(u.avatar_url, '') as actor_avatar_url,
              fe.created_at, fe.updated_at
       from feedback_entries fe
       left join users u on u.name = fe.actor_username
       ${clause}
       order by fe.created_at desc
       limit ${pageSize} offset ${offset}`,
      params
    );
    const [{ count }] = await sql().unsafe(
      `select count(*)::text as count from feedback_entries ${clause}`,
      params
    ) as Array<{ count: string }>;
    return { items: rows as FeedbackEntry[], page, pageSize, total: Number(count) };
  }

  const limit = Math.min(Math.max(Number(input.limit ?? 50) || 50, 1), 200);
  const rows = await sql().unsafe(
    `select fe.id, fe.project_name, fe.kind, fe.title, fe.body, fe.labels, fe.status,
            fe.actor_username, fe.actor_role, coalesce(u.avatar_url, '') as actor_avatar_url,
            fe.created_at, fe.updated_at
     from feedback_entries fe
     left join users u on u.name = fe.actor_username
     ${clause}
     order by fe.created_at desc
     limit ${limit}`,
    params
  );
  return rows as FeedbackEntry[];
}

export async function createFeedback(input: {
  project_name: string;
  kind: FeedbackKind;
  title: string;
  body: string;
  labels: string[];
  status: FeedbackStatus;
  actor_username: string;
  actor_role: string;
}) {
  const [row] = await sql()<
    FeedbackEntry[]
  >`insert into feedback_entries (project_name, kind, title, body, labels, status, actor_username, actor_role)
    values (${input.project_name}, ${input.kind}, ${input.title}, ${input.body}, ${input.labels}, ${input.status}, ${input.actor_username}, ${input.actor_role})
    returning id, project_name, kind, title, body, labels, status, actor_username, actor_role, created_at, updated_at`;
  if (row) {
    const avatarRow = await sql()<Array<{ avatar_url: string }>>`select coalesce(avatar_url, '') as avatar_url from users where name = ${input.actor_username} limit 1`;
    (row as any).actor_avatar_url = avatarRow[0]?.avatar_url ?? '';
  }
  return row ?? null;
}

export async function updateFeedback(input: { id: string; status?: FeedbackStatus; labels?: string[] }) {
  const fields: string[] = [];
  const params: any[] = [];

  if (input.status) {
    params.push(input.status);
    fields.push(`status = $${params.length}`);
  }
  if (input.labels) {
    params.push(input.labels);
    fields.push(`labels = $${params.length}`);
  }
  params.push(input.id);
  fields.push(`updated_at = now()`);
  const setClause = fields.join(", ");

  const rows = await sql().unsafe(
    `update feedback_entries set ${setClause}
     where id = $${params.length}
     returning id, project_name, kind, title, body, labels, status, actor_username, actor_role, created_at, updated_at`,
    params
  );
  const row = (rows as FeedbackEntry[])[0] ?? null;
  if (row) {
    const avatarRow = await sql()<Array<{ avatar_url: string }>>`select coalesce(avatar_url, '') as avatar_url from users where name = ${row.actor_username} limit 1`;
    (row as any).actor_avatar_url = avatarRow[0]?.avatar_url ?? '';
  }
  return row;
}

