import { sql } from "../db/client";

const dbEnabled = Boolean(process.env.DATABASE_URL);

const SUPERADMIN_INITIAL_USERNAME = (process.env.SUPERADMIN_INITIAL_USERNAME ?? "lincube").trim();

export type Capability = {
  id: string;
  name: string;
  category: string;
  description: string;
  sort_index: number;
};

const ALL_CAPABILITIES: Capability[] = [
  { id: "user:comment", name: "发表评论", category: "user.social", description: "发表项目评论", sort_index: 100 },
  { id: "user:feedback", name: "提交反馈", category: "user.social", description: "提交 Bug 反馈", sort_index: 110 },
  { id: "user:profile", name: "修改资料", category: "user.personal", description: "修改个人资料", sort_index: 200 },
  { id: "user:avatar", name: "上传头像", category: "user.personal", description: "上传和更改头像", sort_index: 210 },
  { id: "user:rename", name: "修改用户名", category: "user.personal", description: "修改自己的用户名", sort_index: 220 },
  { id: "user:submit_project", name: "提交项目", category: "user.contribute", description: "提交新项目申请", sort_index: 300 },
  { id: "user:create_org", name: "创建组织", category: "user.contribute", description: "申请创建组织", sort_index: 310 },
  { id: "dev_panel_access", name: "访问开发者后台", category: "dev.access", description: "查看和进入开发者后台", sort_index: 1000 },
  { id: "dev:project_edit", name: "编辑项目", category: "dev.project", description: "编辑自己参与的项目", sort_index: 1100 },
  { id: "dev:project_admin", name: "管理项目成员", category: "dev.project_admin", description: "添加/移除项目协作者、转让所有权", sort_index: 1120 },
  { id: "dev:org_manage", name: "管理组织", category: "dev.org", description: "管理组织设置和成员", sort_index: 1130 },
  { id: "dev:comment_manage", name: "管理评论", category: "dev.interact", description: "管理自己项目的评论", sort_index: 1200 },
  { id: "dev:bug_manage", name: "管理 Bug", category: "dev.interact", description: "处理自己项目的 Bug 反馈", sort_index: 1210 },
  { id: "dev:stats_view", name: "查看数据", category: "dev.data", description: "查看自己项目的统计数据", sort_index: 1300 },
  { id: "dev:developer_manage", name: "开发者管理", category: "dev.data", description: "管理开发者和组织申请", sort_index: 1310 },
  { id: "admin_panel_access", name: "访问运维后台", category: "ops.access", description: "查看和进入运维管理后台", sort_index: 2000 },
  { id: "project:read", name: "查看项目", category: "ops.project", description: "查看项目列表和详情", sort_index: 2100 },
  { id: "project:create", name: "创建项目", category: "ops.project", description: "创建新项目", sort_index: 2110 },
  { id: "project:update", name: "编辑项目", category: "ops.project", description: "编辑项目信息", sort_index: 2120 },
  { id: "project:delete", name: "删除项目", category: "ops.project", description: "删除项目", sort_index: 2130 },
  { id: "project:rollback", name: "版本回滚", category: "ops.project", description: "回滚项目到历史版本", sort_index: 2140 },
  { id: "project:import", name: "批量导入", category: "ops.project", description: "导入 JSON/CSV 数据", sort_index: 2150 },
  { id: "project:export", name: "批量导出", category: "ops.project", description: "导出项目数据", sort_index: 2160 },
  { id: "category:manage", name: "分类管理", category: "ops.project", description: "增删改分类", sort_index: 2170 },
  { id: "submission:read", name: "查看提交", category: "ops.review", description: "查看项目提交列表", sort_index: 2200 },
  { id: "submission:approve", name: "审核通过", category: "ops.review", description: "批准项目提交", sort_index: 2210 },
  { id: "submission:reject", name: "审核驳回", category: "ops.review", description: "驳回项目提交", sort_index: 2220 },
  { id: "moderation:read", name: "查看审核队列", category: "ops.review", description: "查看内容审核队列", sort_index: 2230 },
  { id: "moderation:approve", name: "批准内容", category: "ops.review", description: "批准评论或 Bug 反馈", sort_index: 2240 },
  { id: "moderation:reject", name: "驳回内容", category: "ops.review", description: "驳回评论或 Bug 反馈", sort_index: 2250 },
  { id: "org:review", name: "审核组织", category: "ops.review", description: "审核组织创建申请", sort_index: 2260 },
  { id: "claim:review", name: "审核认领", category: "ops.review", description: "审核项目认领申请", sort_index: 2270 },
  { id: "story:manage", name: "故事管理", category: "ops.content", description: "管理首页故事", sort_index: 2300 },
  { id: "feedback:manage", name: "反馈管理", category: "ops.content", description: "管理反馈状态和标签", sort_index: 2310 },
  { id: "comment:manage", name: "管理评论", category: "ops.content", description: "管理自己和他人的评论/Issue状态", sort_index: 2320 },
  { id: "media:read", name: "查看媒体", category: "ops.content", description: "查看媒体资产和引用关系", sort_index: 2330 },
  { id: "media:manage", name: "管理媒体", category: "ops.content", description: "软删除和恢复媒体资产", sort_index: 2340 },
  { id: "user:read", name: "查看用户", category: "ops.system", description: "查看用户列表", sort_index: 2400 },
  { id: "user:manage", name: "管理用户", category: "ops.system", description: "修改用户角色、状态、权限", sort_index: 2410 },
  { id: "user:delete", name: "删除用户", category: "ops.system", description: "删除用户账号", sort_index: 2420 },
  { id: "audit:read", name: "查看审计日志", category: "ops.system", description: "查看系统审计日志", sort_index: 2430 },
  { id: "org:manage", name: "管理组织", category: "ops.system", description: "管理组织状态", sort_index: 2440 },
  { id: 'route:manage', name: '路由管理', category: 'ops.system', description: '管理网站路由页面', sort_index: 2450 },
  { id: 'analytics:read', name: '查看数据分析', category: 'admin.analytics', description: '查看网站访问统计和用户行为分析', sort_index: 2500 },
];

const ALL_CAPABILITY_IDS = new Set(ALL_CAPABILITIES.map(c => c.id));

export function getAllCapabilities(): Capability[] {
  return [...ALL_CAPABILITIES];
}

export function getAllCapabilityIds(): string[] {
  return ALL_CAPABILITIES.map(c => c.id);
}

export function isSuperadmin(username: string): boolean {
  return username.trim().toLowerCase() === SUPERADMIN_INITIAL_USERNAME.toLowerCase();
}

export async function listCapabilities(): Promise<Capability[]> {
  if (!dbEnabled) return ALL_CAPABILITIES;
  const rows = await sql()<Capability[]>`
    select id, name, category, description, sort_index
    from capabilities
    order by sort_index
  `;
  return rows;
}

export async function getUserCapabilities(userId: string): Promise<string[]> {
  if (!dbEnabled) return ALL_CAPABILITIES.map(c => c.id);
  const rows = await sql()<Array<{ capability_id: string }>>`
    select capability_id from user_capabilities where user_id = ${userId}
  `;
  return rows.map(r => r.capability_id);
}

export async function userHasCapability(userId: string, username: string, capabilityId: string): Promise<boolean> {
  if (isSuperadmin(username)) return true;
  if (!ALL_CAPABILITY_IDS.has(capabilityId)) return false;
  if (!dbEnabled) return true;
  const rows = await sql()<Array<{ capability_id: string }>>`
    select capability_id from user_capabilities where user_id = ${userId} and capability_id = ${capabilityId}
  `;
  return rows.length > 0;
}

export async function setUserCapabilities(userId: string, capabilityIds: string[]): Promise<void> {
  const validIds = capabilityIds.filter(id => ALL_CAPABILITY_IDS.has(id));
  if (!dbEnabled) return;
  await sql()`delete from user_capabilities where user_id = ${userId}`;
  if (validIds.length === 0) return;
  const values = validIds.map(cid => `('${userId}', '${cid}')`).join(", ");
  await sql().unsafe(`insert into user_capabilities (user_id, capability_id) values ${values} on conflict do nothing`);
}

export async function grantCapabilities(userId: string, capabilityIds: string[]): Promise<void> {
  const validIds = capabilityIds.filter(id => ALL_CAPABILITY_IDS.has(id));
  if (!dbEnabled || validIds.length === 0) return;
  const values = validIds.map(cid => `('${userId}', '${cid}')`).join(", ");
  await sql().unsafe(`insert into user_capabilities (user_id, capability_id) values ${values} on conflict do nothing`);
}

export async function grantDefaultUserCapabilities(userId: string): Promise<void> {
  const userCaps = ROLE_TEMPLATES.user.capabilityIds;
  await grantCapabilities(userId, userCaps);
}

export async function getUserCapabilitiesWithInfo(userId: string, username: string): Promise<{
  is_superadmin: boolean;
  capabilities: string[];
  all_capabilities: Capability[];
}> {
  const allCaps = await listCapabilities();
  if (isSuperadmin(username)) {
    return {
      is_superadmin: true,
      capabilities: allCaps.map(c => c.id),
      all_capabilities: allCaps,
    };
  }
  const userCaps = await getUserCapabilities(userId);
  return {
    is_superadmin: false,
    capabilities: userCaps,
    all_capabilities: allCaps,
  };
}

export type RoleTemplate = {
  name: string;
  capabilityIds: string[];
};

export const ROLE_TEMPLATES: Record<string, RoleTemplate> = {
  user: {
    name: "用户",
    capabilityIds: [
      "user:comment", "user:avatar", "user:feedback",
      "user:submit_project", "user:profile", "user:rename", "user:create_org",
    ],
  },
  developer: {
    name: "开发者",
    capabilityIds: [
      "user:comment", "user:avatar", "user:feedback",
      "user:submit_project", "user:profile", "user:rename", "user:create_org",
      "dev_panel_access",
      "dev:project_edit", "dev:project_admin", "dev:org_manage",
      "dev:bug_manage", "dev:comment_manage", "dev:stats_view",
    ],
  },
  editor: {
    name: "编者",
    capabilityIds: [
      "admin_panel_access",
      "project:read", "project:create", "project:update",
      "story:manage", "media:read", "media:manage",
      "submission:read", "submission:approve", "submission:reject",
      "moderation:read", "moderation:approve", "moderation:reject",
      "comment:manage",
    ],
  },
  ops: {
    name: "运维",
    capabilityIds: getAllCapabilityIds(),
  },
};

export function getRoleTemplates(): Record<string, RoleTemplate> {
  return ROLE_TEMPLATES;
}
